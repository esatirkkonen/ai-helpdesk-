# CloudwebAI Helpdesk — Tietokanta dokumentaatio

## Yleiskatsaus

Tietokanta on **PostgreSQL 18** ja se sisältää 9 taulua. Tietokanta pyörii tällä hetkellä lokaalisti kehityskoneella, tuotannossa Hostinger VPS:llä.

---

## Yhteyskonfiguraatio

**Lokaali kehitys:**
```
Host:     localhost
Port:     5432
Database: helpdesk
User:     postgres
Password: [asennuksen aikana asetettu]
```

**Tuotanto (VPS):**
```
Host:     localhost (VPS sisäinen)
Port:     5432
Database: helpdesk
User:     helpdesk_user
Password: [tuotantosalasana .env:ssä]
```

---

## Taulut

### `companies` — Asiakasyritykset
Kaikki asiakasyritykset. Jokainen käyttäjä kuuluu yritykseen.

| Kenttä | Tyyppi | Kuvaus |
|---|---|---|
| id | UUID PK | Yksilöivä tunniste |
| name | VARCHAR(255) | Yrityksen nimi |
| contact_email | VARCHAR(255) | Yhteyshenkilön sähköposti |
| phone | VARCHAR(50) | Puhelinnumero |
| created_at | TIMESTAMP | Luontiaika |

---

### `users` — Käyttäjät
Kaikki järjestelmän käyttäjät: asiakkaat, agentit ja adminit.

| Kenttä | Tyyppi | Kuvaus |
|---|---|---|
| id | UUID PK | Yksilöivä tunniste |
| company_id | UUID FK | Viittaus companies-tauluun |
| name | VARCHAR(255) | Koko nimi |
| email | VARCHAR(255) UNIQUE | Sähköposti (käyttäjätunnus) |
| password_hash | VARCHAR(255) | bcrypt-salattu salasana |
| role | VARCHAR(20) | customer / agent / admin |
| phone | VARCHAR(50) | Puhelinnumero |
| active | BOOLEAN | Onko tili aktiivinen |
| created_at | TIMESTAMP | Luontiaika |

**Roolit:**
- `customer` — voi luoda tikettejä ja seurata omia tikettejään
- `agent` — voi käsitellä kaikkia tikettejä
- `admin` — täydet oikeudet + käyttäjähallinta

---

### `tickets` — Tiketit
Järjestelmän ydinentiteetti. Sisältää kaiken tikettiin liittyvän tiedon.

| Kenttä | Tyyppi | Kuvaus |
|---|---|---|
| id | UUID PK | Yksilöivä tunniste |
| customer_id | UUID FK | Tiketin luoja (users) |
| agent_id | UUID FK | Käsittelijä (users), voi olla NULL |
| title | VARCHAR(255) | Otsikko |
| description | TEXT | Tarkempi kuvaus |
| status | VARCHAR(20) | Tiketin tila (ks. alla) |
| priority | VARCHAR(20) | Matala / Normaali / Kiireellinen |
| time_spent_seconds | INT | Kokonaistyöaika sekunteina |
| started_at | TIMESTAMP | Milloin otettu työn alle |
| resolved_at | TIMESTAMP | Milloin merkitty valmiiksi |
| created_at | TIMESTAMP | Luontiaika |
| updated_at | TIMESTAMP | Viimeisin päivitys |

**Tiketit tilat:**
- `Avoin` — uusi tiketti, ei käsittelijää
- `Työn alla` — agentti käsittelee, ajanlasku käynnissä
- `Odottaa` — odottaa asiakasta/kolmatta osapuolta, ajanlasku pysäytetty
- `Valmis` — ratkaistu, ajanlasku pysäytetty
- `Keskeytetty` — peruutettu, ajanlasku pysäytetty

---

### `time_logs` — Aikalokit
Jokainen tilanmuutos "Työn alla" ↔ muut tilat tallennetaan. Käytetään tarkan työajan laskemiseen.

| Kenttä | Tyyppi | Kuvaus |
|---|---|---|
| id | UUID PK | Yksilöivä tunniste |
| ticket_id | UUID FK | Tiketti |
| agent_id | UUID FK | Agentti joka teki muutoksen |
| started_at | TIMESTAMP | Milloin aloitettiin |
| stopped_at | TIMESTAMP | Milloin pysäytettiin |
| seconds | INT | Laskettu kesto sekunteina |
| reason | VARCHAR(50) | Miksi pysäytetty (paused/resolved/cancelled) |
| created_at | TIMESTAMP | Luontiaika |

**Ajanlasku-logiikka:**
```
status → "Työn alla":  INSERT time_log (started_at = NOW())
status → "Odottaa":    UPDATE time_log SET stopped_at = NOW(), seconds = ...
status → "Valmis":     UPDATE time_log SET stopped_at = NOW(), seconds = ...
                       UPDATE ticket SET time_spent_seconds = SUM(time_logs.seconds)
```

---

### `comments` — Kommentit
Tikettien sisäiset muistiinpanot ja asiakkaalle näkyvät viestit.

| Kenttä | Tyyppi | Kuvaus |
|---|---|---|
| id | UUID PK | Yksilöivä tunniste |
| ticket_id | UUID FK | Tiketti |
| user_id | UUID FK | Kommentin kirjoittaja |
| content | TEXT | Kommenttiteksti |
| is_internal | BOOLEAN | TRUE = vain agentit näkee |
| created_at | TIMESTAMP | Luontiaika |

---

### `email_logs` — Sähköpostiloki
Kaikki järjestelmän lähettämät sähköpostit talteen.

| Kenttä | Tyyppi | Kuvaus |
|---|---|---|
| id | UUID PK | Yksilöivä tunniste |
| ticket_id | UUID FK | Tiketti |
| to_email | VARCHAR(255) | Vastaanottaja |
| subject | VARCHAR(255) | Aihe |
| type | VARCHAR(50) | ticket_created / status_changed / reply_sent |
| sent_at | TIMESTAMP | Lähetysaika |

---

### `ai_suggestions` — AI-ehdotukset
Jokainen AI:n generoima vastausehdotus tallennetaan oppimista varten.

| Kenttä | Tyyppi | Kuvaus |
|---|---|---|
| id | UUID PK | Yksilöivä tunniste |
| ticket_id | UUID FK | Tiketti |
| agent_id | UUID FK | Agentti joka käsitteli |
| original_suggestion | TEXT | AI:n alkuperäinen ehdotus |
| final_response | TEXT | Mitä lopulta lähetettiin |
| outcome | VARCHAR(20) | accepted / edited / rejected |
| similarity_score | FLOAT | 0-1, kuinka paljon muokattiin |
| model_used | VARCHAR(100) | Käytetty AI-malli |
| response_time_ms | INT | AI:n vasteaika millisekunteina |
| created_at | TIMESTAMP | Luontiaika |

**outcome-arvot:**
- `accepted` — agentti lähetti AI:n ehdotuksen sellaisenaan
- `edited` — agentti muokkasi ennen lähetystä
- `rejected` — agentti hylkäsi ja kirjoitti itse

---

### `solution_kb` — Ratkaisupankki
Hyväksytyt ratkaisut tallennetaan tietopankkiin. AI hakee ensin täältä ennen RAG-hakua dokumenteista.

| Kenttä | Tyyppi | Kuvaus |
|---|---|---|
| id | UUID PK | Yksilöivä tunniste |
| ticket_id | UUID FK | Mistä tiketistä peräisin |
| problem_category | VARCHAR(100) | Ongelmatyyppi (VPN, salasana, jne.) |
| problem_keywords | TEXT | Hakusanat |
| solution_text | TEXT | Ratkaisu |
| times_used | INT | Kuinka monta kertaa käytetty |
| success_rate | FLOAT | Onnistumisprosentti (0-1) |
| verified | BOOLEAN | Admin on vahvistanut luotettavaksi |
| created_at | TIMESTAMP | Luontiaika |
| updated_at | TIMESTAMP | Viimeisin päivitys |

---

### `rag_feedback` — RAG-palaute
Tallennetaan mitkä dokumentit auttoivat AI:ta. Käytetään RAG-haun parantamiseen.

| Kenttä | Tyyppi | Kuvaus |
|---|---|---|
| id | UUID PK | Yksilöivä tunniste |
| suggestion_id | UUID FK | AI-ehdotus |
| doc_name | VARCHAR(255) | Dokumentin nimi |
| relevance_score | FLOAT | Relevanssipisteet (0-1) |
| was_helpful | BOOLEAN | Oliko dokumentti hyödyllinen |
| created_at | TIMESTAMP | Luontiaika |

---

## Tärkeimmät kyselyt

### Avoimet tiketit
```sql
SELECT t.*, u.name as customer_name, c.name as company_name
FROM tickets t
JOIN users u ON t.customer_id = u.id
JOIN companies c ON u.company_id = c.id
WHERE t.status = 'Avoin'
ORDER BY t.created_at DESC;
```

### Agentin tiketit
```sql
SELECT * FROM tickets
WHERE agent_id = 'uuid-here'
AND status != 'Valmis'
ORDER BY created_at DESC;
```

### Tikettien vastausajat (raportti)
```sql
SELECT
  c.name as company,
  COUNT(t.id) as total_tickets,
  AVG(EXTRACT(EPOCH FROM (t.started_at - t.created_at))/3600) as avg_response_hours,
  AVG(EXTRACT(EPOCH FROM (t.resolved_at - t.created_at))/3600) as avg_resolution_hours,
  AVG(t.time_spent_seconds/60) as avg_work_minutes
FROM tickets t
JOIN users u ON t.customer_id = u.id
JOIN companies c ON u.company_id = c.id
WHERE t.resolved_at IS NOT NULL
GROUP BY c.name;
```

### AI:n tehokkuus
```sql
SELECT
  outcome,
  COUNT(*) as count,
  AVG(similarity_score) as avg_similarity,
  AVG(response_time_ms) as avg_response_ms
FROM ai_suggestions
GROUP BY outcome;
```

---

## Testidata

Järjestelmässä on valmiiksi seuraavat testikäyttäjät:

| Nimi | Email | Rooli | Yritys |
|---|---|---|---|
| Jukka Korhonen | jukka@acme.fi | customer | Acme Oy |
| Sari Mäkinen | sari@beta.fi | customer | Beta Corp |
| Pekka Virtanen | pekka@gamma.fi | customer | Gamma Ltd |
| Matti Tukihenkilö | matti@cloudwebai.fi | agent | Acme Oy |
| Tiina Agentti | tiina@cloudwebai.fi | agent | Acme Oy |
| Admin Käyttäjä | admin@cloudwebai.fi | admin | Acme Oy |

**Huom:** Testikäyttäjien salasanat ovat placeholder-hasheja. Backend luo oikeat bcrypt-hashit kun auth on toteutettu.

---

## Migraatiot

Taulut luodaan `schema.sql`-tiedostolla:
```bash
psql -U postgres -d helpdesk -f backend/schema.sql
```

Tulevat muutokset tehdään erillisillä migraatiotiedostoilla:
```bash
backend/migrations/001_add_column.sql
backend/migrations/002_add_index.sql
```

---

## Indeksit (TODO)

Lisätään myöhemmin suorituskyvyn parantamiseksi:
```sql
CREATE INDEX idx_tickets_status ON tickets(status);
CREATE INDEX idx_tickets_agent ON tickets(agent_id);
CREATE INDEX idx_tickets_customer ON tickets(customer_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_time_logs_ticket ON time_logs(ticket_id);
```
