# CloudwebAI Helpdesk — Frontend dokumentaatio

## Yleiskatsaus

Frontend on rakennettu **Next.js 14** (App Router) + **TypeScript** + **Tailwind CSS** -yhdistelmällä. Kaikki näkymät käyttävät tällä hetkellä mock-dataa — backend-kytkentä tehdään erikseen.

---

## Teknologiat

| Teknologia | Versio | Käyttötarkoitus |
|---|---|---|
| Next.js | 14+ | React-framework, App Router |
| TypeScript | 5+ | Tyyppiturvallisuus |
| Tailwind CSS | 3+ | Tyylittely |
| React | 18+ | UI-komponentit |

---

## Kansiorakenne

```
frontend/
├── app/                        # Next.js App Router
│   ├── layout.tsx              # Yhteinen layout kaikille sivuille
│   ├── page.tsx                # Juurisivu → ohjaa /login-sivulle
│   ├── login/
│   │   └── page.tsx            # Kirjautumissivu
│   ├── customer/
│   │   └── page.tsx            # Asiakkaan näkymä
│   ├── tickets/
│   │   └── page.tsx            # Tikettilista (agentti/admin)
│   ├── dashboard/
│   │   └── page.tsx            # Agenttinäkymä
│   └── admin/
│       └── page.tsx            # Admin-näkymä
├── components/                 # Uudelleenkäytettävät komponentit (tulossa)
├── lib/                        # Apufunktiot (tulossa)
│   ├── api.ts                  # Backend API -kutsut
│   └── auth.ts                 # JWT-käsittely
├── types/                      # TypeScript-tyypit (tulossa)
│   └── index.ts
├── public/                     # Staattiset tiedostot
├── next.config.ts
├── tailwind.config.ts
├── tsconfig.json
└── package.json
```

---

## Näkymät

### `/login` — Kirjautumissivu
**Tiedosto:** `app/login/page.tsx`

Kirjautumislomake joka lähettää `POST /auth/login` backendille. Vastauksen `role`-kenttä määrää mihin ohjataan:
- `admin` → `/admin`
- `agent` → `/dashboard`
- `customer` → `/customer`

JWT-token tallennetaan `localStorage`en avaimella `token`.

**Tila (state):**
- `email` — sähköpostikentän arvo
- `password` — salasanakentän arvo
- `error` — virheilmoitus
- `loading` — lataustila

---

### `/customer` — Asiakkaan näkymä
**Tiedosto:** `app/customer/page.tsx`

Kaksi näkymää toggle-napilla:
1. **Tikettilista** — näyttää käyttäjän omat tiketit statuksineen
2. **Uusi tiketti -lomake** — otsikko, kuvaus, prioriteetti

**Tyypit:**
```typescript
type Ticket = {
  id: string
  title: string
  status: 'Avoin' | 'Työn alla' | 'Odottaa' | 'Valmis' | 'Keskeytetty'
  created: string
  updated: string
}
```

**Prioriteetit:** Matala | Normaali | Kiireellinen

**TODO (backend-kytkentä):**
- `GET /tickets?customer_id=me` — hae omat tiketit
- `POST /tickets` — luo uusi tiketti

---

### `/tickets` — Tikettilista
**Tiedosto:** `app/tickets/page.tsx`

Taulukkonäkymä kaikista tiketeistä. Hakutoiminto ja statussuodatus. Klikkaamalla tikettiriviä aukeaa oikeanpuolen detaljipaneeli.

**Tyypit:**
```typescript
type Ticket = {
  id: string
  title: string
  status: Status
  priority: Priority
  customer: string
  company: string
  agent: string | null
  created: string
  updated: string
}
```

**Suodatus:**
- Tekstihaku: otsikko, asiakas, yritys, ID
- Statussuodatus: Kaikki | Avoin | Työn alla | Odottaa | Valmis | Keskeytetty

**TODO (backend-kytkentä):**
- `GET /tickets` — hae kaikki tiketit
- `GET /tickets?status=Avoin` — suodatettu haku

---

### `/dashboard` — Agenttinäkymä
**Tiedosto:** `app/dashboard/page.tsx`

Tärkein näkymä. Vasemmalla tikettilista, oikealla valitun tiketin tiedot.

**Toiminnallisuudet:**
- Tiketin valinta vasemmalta listalta
- Tilan vaihto (Avoin → Työn alla → Odottaa → Valmis → Keskeytetty)
- Ajanlasku — käynnistyy automaattisesti kun tila = "Työn alla", pysähtyy kun "Odottaa"/"Valmis"/"Keskeytetty"
- Agentin vaihto dropdown-valikosta
- AI-ehdotuksen näyttäminen ja muokkaus
- Vastauksen lähetys asiakkaalle

**Ajanlasku-logiikka:**
```typescript
// Timers tallennetaan React statessa
const [timers, setTimers] = useState<Record<string, number>>({})
const [running, setRunning] = useState<Record<string, boolean>>({})

// Käynnistyy kun status → "Työn alla"
// Pysähtyy kun status → "Odottaa" | "Valmis" | "Keskeytetty"
```

**Asiakkaan tiedot näytetään:** nimi, yritys, sähköposti, puhelin

**TODO (backend-kytkentä):**
- `GET /tickets` — hae tiketit
- `PUT /tickets/:id/status` — vaihda tila
- `PUT /tickets/:id/agent` — vaihda agentti
- `POST /tickets/:id/reply` — lähetä vastaus
- `POST /tickets/:id/time` — tallenna aika

---

### `/admin` — Admin-näkymä
**Tiedosto:** `app/admin/page.tsx`

Kaksi välilehteä: **Käyttäjät** ja **Yritykset**.

**Käyttäjät-välilehti:**
- Taulukko kaikista käyttäjistä
- Haku nimellä, sähköpostilla tai yrityksellä
- Suodatus roolin mukaan (Asiakas | Agentti | Admin)
- Käyttäjän aktivointi/deaktivointi napilla
- Uuden käyttäjän lisäys modaalilla

**Yritykset-välilehti:**
- Taulukko yrityksistä
- Uuden yrityksen lisäys modaalilla

**Roolit:**
```typescript
type Role = 'customer' | 'agent' | 'admin'
```

**TODO (backend-kytkentä):**
- `GET /users` — hae käyttäjät
- `POST /users` — lisää käyttäjä
- `PUT /users/:id/active` — aktivoi/deaktivoi
- `GET /companies` — hae yritykset
- `POST /companies` — lisää yritys

---

## Värikoodi statuksille

```typescript
const statusColors = {
  'Avoin':       'bg-amber-500/10 text-amber-400 border-amber-500/20',
  'Työn alla':   'bg-blue-500/10 text-blue-400 border-blue-500/20',
  'Odottaa':     'bg-purple-500/10 text-purple-400 border-purple-500/20',
  'Valmis':      'bg-green-500/10 text-green-400 border-green-500/20',
  'Keskeytetty': 'bg-red-500/10 text-red-400 border-red-500/20',
}
```

---

## Backend-kytkentä (TODO)

Kun backend on valmis, jokaisessa `page.tsx`-tiedostossa on merkitty `// TODO` -kommentit. Yleiset muutokset:

1. Poista mock-data tiedoston alusta
2. Lisää `useEffect` joka hakee datan backendilta
3. Lisää `Authorization: Bearer ${token}` header kaikkiin kutsuihin

**Esimerkki:**
```typescript
// Ennen (mock-data):
const [tickets, setTickets] = useState(mockTickets)

// Jälkeen (backend):
const [tickets, setTickets] = useState([])

useEffect(() => {
  const token = localStorage.getItem('token')
  fetch('http://localhost:8000/tickets', {
    headers: { Authorization: `Bearer ${token}` }
  })
  .then(r => r.json())
  .then(data => setTickets(data))
}, [])
```

---

## Kehitysympäristö

```bash
cd frontend
npm install
npm run dev
# → http://localhost:3000
```

---

## Ympäristömuuttujat

Luo `frontend/.env.local`:
```
NEXT_PUBLIC_API_URL=http://localhost:8000
```

Tuotannossa:
```
NEXT_PUBLIC_API_URL=https://api.cloudwebai.fi
```
